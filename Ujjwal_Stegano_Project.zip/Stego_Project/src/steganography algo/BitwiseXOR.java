package steganography;

import java.awt.image.BufferedImage;
import javax.swing.JLabel;
import utility.ImageUtility;


public class BitwiseXOR {
    

    private int[] mapping(int index) {
        
        // mapping[0] is source bit and mapping[1] is target bit
        int mapping[] = new int[2];
        
        if (index <= 4) {
            mapping[0] = 7;
            mapping[1] = index - 1;
        } else if (index <= 8) {
            mapping[0] = 6;
            mapping[1] = index - 4 - 1;
        } else if (index <= 12) {
            mapping[0] = 5;
            mapping[1] = index - 8 - 1;
        } else if (index <= 16) {
            mapping[0] = 4;
            mapping[1] = index - 12 - 1;
        } else if (index <= 19) {
            mapping[0] = 3;
            mapping[1] = index - 16 - 1;
        } else if (index <= 22) {
            mapping[0] = 2;
            switch (index) {
                case 20: {
                    mapping[1] = 0;
                    break;
                }
                case 21: {
                    mapping[1] = 1;
                    break;
                }
                case 22: {
                    mapping[1] = 3;
                    break;
                }
            }
        } else if (index <= 25) {
            mapping[0] = 1;
            switch (index) {
                case 23: {
                    mapping[1] = 0;
                    break;
                }
                case 24: {
                    mapping[1] = 2;
                    break;
                }
                case 25: {
                    mapping[1] = 3;
                    break;
                }
            }
        } else if (index <= 28) {
            mapping[0] = 0;
            switch (index) {
                case 26: {
                    mapping[1] = 1;
                    break;
                }
                case 27: {
                    mapping[1] = 2;
                    break;
                }
                case 28: {
                    mapping[1] = 3;
                    break;
                }
            }
        }
        return mapping;
    }
    
    public void xor(BufferedImage userSpaceImage, int bitwiseXORIndex,
            int pixelSize, JLabel nameLabel) {
        int mapping[] = mapping(bitwiseXORIndex);
        int sourceBit = mapping[0];
        int targetBit = mapping[1];
        ImageUtility imageUtility = new ImageUtility();
        byte image[] = imageUtility.getByteData(userSpaceImage);
        int bytesPerPixel = pixelSize / 8;
        for (int i = 0; i < image.length; i += bytesPerPixel) {
            for (int j = 0; j < bytesPerPixel; j++) {
                int sourceBitValue = (image[i + j] >> sourceBit) & 1;
                int targetBitValue = (image[i + j] >> targetBit) & 1;
                int singleBit = sourceBitValue ^ targetBitValue;
                if (singleBit == 0) {
                    image[i + j] = 0x00;
                } else {
                    image[i + j] = (byte) 128;
                }
            }
        }
        nameLabel.setText("Source bit: " + sourceBit + " Target bit: " +
                targetBit);
    }
}
