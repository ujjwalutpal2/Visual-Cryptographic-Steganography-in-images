
package steganography;

import java.awt.image.BufferedImage;
import utility.ImageUtility;


public class BitPlane {
    
    public void singlePlane(BufferedImage userSpaceImage, int bpcsIndex, 
            int pixelSize) {
        ImageUtility imageUtility = new ImageUtility();
        byte image[] = imageUtility.getByteData(userSpaceImage);
        int bytesPerPixel = pixelSize / 8;
        int start = bpcsIndex / 8;
        bpcsIndex = bpcsIndex % 8;
        int shift = 7 - bpcsIndex;
        for (int i = 0; i < image.length; i += bytesPerPixel) {
            for (int j = 0; j < bytesPerPixel; j++) {
                if (j != start) {
                    image[i + j] = 0x00;
                }
            }
            int singleBit = (image[i + start] >> shift) & 1;
            if (singleBit == 0) {
                image[i + start] = 0x00;
            } else {
                image[i + start] = (byte) 128;
            }
        }
    }
    
    public void allPlane(BufferedImage userSpaceImage, int bpcsIndex, 
            int pixelSize) {
        ImageUtility imageUtility = new ImageUtility();
        byte image[] = imageUtility.getByteData(userSpaceImage);
        int bytesPerPixel = pixelSize / 8;

        bpcsIndex = (bpcsIndex * -1) - 1;
        for (int i = 0; i < image.length; i += bytesPerPixel) {
            for (int j = 0; j < bytesPerPixel; j++) {
                int singleBit = (image[i + j] >> bpcsIndex) & 1;
                if (singleBit == 0) {
                    image[i + j] = 0x00;
                } else {
                    image[i + j] = (byte) 128;
                }
            }
        }
    }
    
    public void hideImage(BufferedImage coverImage, BufferedImage targetImage,
            int lsb, boolean invertBits) {
        ImageUtility imageUtility = new ImageUtility();
        byte cover[] = imageUtility.getByteData(coverImage);
        byte target[] = imageUtility.getByteData(targetImage);
        int coverLength = cover.length;
        int targetLength = target.length;
        int i = 0;
        while (i < coverLength && i < targetLength) {
            int msbOfTarget = (target[i] >> 7) & 1;
            if (invertBits) {
                msbOfTarget = (~msbOfTarget) & 1;
            }
            switch (lsb) {
                case 0: {
                    cover[i] = (byte) ((cover[i] & 0xFE) | msbOfTarget);
                    break;
                }
                case 1: {
                    cover[i] = (byte) ((cover[i] & 0xFD) | 2 * msbOfTarget);
                    break;
                }
                case 2: {
                    cover[i] = (byte) ((cover[i] & 0xFB) | 4 * msbOfTarget);
                    break;
                }
                case 3: {
                    cover[i] = (byte) ((cover[i] & 0xF7) | 8 * msbOfTarget);
                    break;
                }
            }
            i++;
        }
    }
    
    public void hideImage(BufferedImage coverImage, BufferedImage targetImage,
            int lsb, int upperBit) {
        ImageUtility imageUtility = new ImageUtility();
        byte cover[] = imageUtility.getByteData(coverImage);
        byte target[] = imageUtility.getByteData(targetImage);
        int coverLength = cover.length;
        int targetLength = target.length;
        int i = 0;
        while (i < coverLength && i < targetLength) {
            int msbOfTarget = (target[i] >> 7) & 1;
            int upperBitValue = (cover[i] >> upperBit) & 1;
            msbOfTarget = msbOfTarget ^ upperBitValue;
            switch (lsb) {
                case 0: {
                    cover[i] = (byte) ((cover[i] & 0xFE) | msbOfTarget);
                    break;
                }
                case 1: {
                    cover[i] = (byte) ((cover[i] & 0xFD) | 2 * msbOfTarget);
                    break;
                }
                case 2: {
                    cover[i] = (byte) ((cover[i] & 0xFB) | 4 * msbOfTarget);
                    break;
                }
                case 3: {
                    cover[i] = (byte) ((cover[i] & 0xF7) | 8 * msbOfTarget);
                    break;
                }
            }
            i++;
        }
    }
}
